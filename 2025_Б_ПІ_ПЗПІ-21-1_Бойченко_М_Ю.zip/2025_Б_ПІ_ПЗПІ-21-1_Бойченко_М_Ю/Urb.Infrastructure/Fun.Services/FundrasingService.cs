﻿using AutoMapper;
using Fun.Application.ComponentModels;
using Fun.Application.Fun.IRepositories;
using Fun.Application.Fun.IServices;
using Fun.Application.ResponseModels;
using Fun.Domain.Fun.Models;
using Fun.Infrastructure.Hubs;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Urb.Infrastructure.Fun.Services;

namespace Fun.Infrastructure.Fun.Services
{
    public class FundraisingService : IFundraisingService
    {
        private readonly ICRUDRepository<Fundraising> _repo;
        private readonly MainDataContext _ctx;
        private readonly IHttpContextAccessor _httpCtx;
        private readonly IMapper _mapper;
        private readonly IUserService _userService;
        private readonly IHubContext<FundraisingHub> _hubContext;
        private readonly IEmailSender _emailSender;

        public FundraisingService(
            ICRUDRepository<Fundraising> repo,
            MainDataContext ctx,
            IHttpContextAccessor httpCtx,
            IUserService userService, IMapper mapper, IEmailSender emailSender, IHubContext<FundraisingHub> hubContext)
        {
            _repo = repo;
            _ctx = ctx;
            _httpCtx = httpCtx;
            _userService = userService;
            _mapper = mapper;
            _emailSender = emailSender;
            _hubContext = hubContext;
        }

        private string CurrentUserId =>
            _httpCtx.HttpContext!.User.FindFirst(ClaimTypes.NameIdentifier)!.Value!;

        //    public async Task<Fundraising> CreateAsync(FundraisingComponentModel dto)
        //    {
        //        var initiative = await _ctx.Initiatives
        //            .FirstOrDefaultAsync(i => i.Id == dto.InitiativeId);
        //        if (initiative == null)
        //            throw new KeyNotFoundException($"Initiative #{dto.InitiativeId} not found.");

        //        var entity = _mapper.Map<Fundraising>(dto);

        //        entity.CreatedAt = DateTime.UtcNow;
        //        entity.CreatedById = await _userService.GetMy();
        //        entity.Initiative = initiative;

        //        var created = await _repo.Create(entity);

        //        var stat = new FundraisingStat
        //        {
        //            FundraisingId = created.Id,
        //            TotalCollected = 0m,
        //            //CreatedAt = DateTime.UtcNow,
        //            UpdatedAt = DateTime.UtcNow
        //        };
        //        _ctx.FundraisingStats.Add(stat);
        //        //await _ctx.SaveChangesAsync();
        //        var subs = await _ctx.Subscribes
        //.Where(s => s.InitiativeId == created.InitiativeId)
        //.Select(s => s.User)
        //.ToListAsync();

        //        foreach (var user in subs)
        //        {
        //            _ctx.FundraisingNotifications.Add(new FundraisingNotification
        //            {
        //                UserId = user.Id,
        //                FundraisingId = created.Id
        //            });
        //            await _ctx.SaveChangesAsync();
        //            await _hubContext.Clients.Group($"initiative-{dto.InitiativeId}")
        //        .SendAsync("NewFundraisingCreated", new
        //        {
        //            fundraisingId = entity.Id,
        //            title = entity.Title,
        //            goal = entity.GoalAmount,
        //            deadline = entity.Deadline
        //        });
        //            var emails = await _ctx.Subscribes
        //            .Where(s => s.InitiativeId == dto.InitiativeId)
        //            .Select(s => s.User.Email)
        //            .Distinct()
        //            .ToListAsync();

        //            var subject = $"Нова кампанія: {created.Title}";
        //            var body = $"В ініціативі \"{initiative.Title}\" створено новий збір \"{created.Title}\" із ціллю {created.GoalAmount:C}.";

        //            foreach (var email in emails)
        //            {
        //                await _emailSender.SendAsync(email, subject, body);
        //            }

        //            return created;
        //        }
        //    }
        public async Task<Fundraising> CreateAsync(FundraisingComponentModel dto)
        {
            var now = DateTime.UtcNow;
            var initiative = await _ctx.Initiatives
                .FirstOrDefaultAsync(i => i.Id == dto.InitiativeId);
            if (initiative == null)
                throw new KeyNotFoundException($"Initiative #{dto.InitiativeId} not found.");

            var entity = _mapper.Map<Fundraising>(dto);
            entity.CreatedAt = DateTime.UtcNow;
            entity.CreatedById = await _userService.GetMy();
            entity.Initiative = initiative;

            var created = await _repo.Create(entity);

            var stat = new FundraisingStat
            {
                FundraisingId = created.Id,
                TotalCollected = 0m,
                UpdatedAt = DateTime.UtcNow
            };
            _ctx.FundraisingStats.Add(stat);
            var subscribers = await _ctx.Subscribes
                .Where(s => s.InitiativeId == created.InitiativeId)
                .Select(s => s.User)
                .ToListAsync();

            var notifications = subscribers
                .Select(u => new FundraisingNotification
                {
                    UserId = u.Id,
                    FundraisingId = created.Id,
                    CreatedAt = DateTime.UtcNow,
                    IsRead = false
                })
                .ToList();
            _ctx.FundraisingNotifications.AddRange(notifications);

            var subsWithSettings = await _ctx.Subscribes
        .Where(s => s.InitiativeId == created.InitiativeId)
        .Select(s => new {
            User = s.User,
            Setting = s.User.NotificationSetting
        })
        .ToListAsync();
            var toNotifyEmails = new List<string>();
            foreach (var x in subsWithSettings)
            {
                if (x.Setting == null || !x.Setting.NotifyNewFundraising)
                    continue;
                var last = await _ctx.Fundraisings
                    .Where(f => f.InitiativeId == created.InitiativeId && f.Id != created.Id)
                    .OrderByDescending(f => f.CreatedAt)
                    .FirstOrDefaultAsync();

                var freq = TimeSpan.FromHours(x.Setting.FrequencyInHours);
                if (last == null || (now - last.CreatedAt) >= freq)
                    toNotifyEmails.Add(x.User.Email!);
            }
                    await _ctx.SaveChangesAsync();




            await _hubContext
                .Clients
                .Group($"initiative-{created.InitiativeId}")
                .SendAsync("NewFundraisingCreated", new
                {
                    fundraisingId = created.Id,
                    title = created.Title,
                    goal = created.GoalAmount,
                    deadline = created.Deadline
                });
            //var emails = subscribers
            //    .Select(u => u.Email)
            //    .Distinct();

            //var subject = $"Нова кампанія: {created.Title}";
            //var body = $"В ініціативі «{initiative.Title}» створено новий збір «{created.Title}» з метою {created.GoalAmount:C}.";

            //foreach (var email in emails)
            //{
            //    await _emailSender.SendAsync(email, subject, body);
            //}
            var subject = $"Нова кампанія: {created.Title}";
            var body = $"У ініціативі «{initiative.Title}» створено новий збір «{created.Title}» з метою {created.GoalAmount:C}.";
            foreach (var email in toNotifyEmails.Distinct())
            {
                await _emailSender.SendAsync(email, subject, body);
            }
            return created;
        }


        public Task<Fundraising?> GetByIdAsync(int id)
            => _repo.GetByIdAsync(id);

        public async Task<Fundraising> UpdateAsync(Fundraising dto)
        {
            var existing = await _repo.GetByIdAsync(dto.Id);
            if (existing == null) throw new KeyNotFoundException();

            var init = await _ctx.Initiatives
                .FirstOrDefaultAsync(i => i.Id == existing.InitiativeId);
            if (init == null) throw new KeyNotFoundException("Initiative not found");

            return await _repo.Put(dto);
        }

        public async Task DeleteAsync(int id)
        {
            var existing = await _repo.GetByIdAsync(id);
            if (existing == null) throw new KeyNotFoundException();
            var init = await _ctx.Initiatives
                .FirstOrDefaultAsync(i => i.Id == existing.InitiativeId);
            if (init == null) throw new KeyNotFoundException("Initiative not found");
            await _repo.Delete(id);
        }

        //public async Task<IEnumerable<Fundraising>> GetByUserAsync(int userId)
        //{
        //    var userInitiatives = await _ctx.Initiatives.G GetByUserAsync(userId);
        //    var ids = userInitiatives.Select(x => x.Id).ToHashSet();
        //    var all = await _repo.ListAsync();
        //    return all.Where(f => ids.Contains(f.InitiativeId));
        //}

        //public async Task<IEnumerable<Fundraising>> GetByInitiativeAsync(int initiativeId)
        //{
        //    var all = await _repo.ListAsync();
        //    return all.Where(f => f.InitiativeId == initiativeId);
        //}
        public async Task<List<FundraisingResponseTotalCollectedModel>> GetByInitiativeAsync(int initiativeId)
        {
            var list = await _ctx.Fundraisings
                .Where(f => f.InitiativeId == initiativeId)
                .Select(f => new FundraisingResponseTotalCollectedModel
                {
                    Id = f.Id,
                    Title = f.Title,
                    GoalAmount = f.GoalAmount,
                    CreatedAt = f.CreatedAt,
                    Deadline = f.Deadline,
                    TotalCollected = f.Donates.Sum(d => d.Amount),
                    IsBlocked = f.IsBlocked
                })
                .ToListAsync();

            return list;
        }

        public async Task<FundraisingStatisticsComponentModel> GetStatisticsAsync(int fundraisingId)
        {
            var fund = await _ctx.Fundraisings
                .AsNoTracking()
                .Include(f => f.Stat)
                    .ThenInclude(s => s.DailyIncomes)
                .FirstOrDefaultAsync(f => f.Id == fundraisingId);

            if (fund is null)
                throw new KeyNotFoundException($"Fundraising #{fundraisingId} not found.");

            var stat = fund.Stat;
            return new FundraisingStatisticsComponentModel
            {
                FundraisingId = fund.Id,
                Goal = /*stat.Goal*/fund.GoalAmount,
                TotalCollected = stat.TotalCollected,
                UpdatedAt = stat.UpdatedAt,
                DailyIncomes = stat.DailyIncomes
                    .OrderBy(d => d.Date)
                    .Select(d => new FundraisingDailyIncomeComponentModel
                    {
                        Date = d.Date,
                        Amount = d.Amount
                    })
                    .ToList()
            };
        }
        public async Task<List<FundraisingResponseTotalCollectedModel>> GetAllFundraisingsAsync()
        {
            return await _ctx.Fundraisings
                .AsNoTracking()
                .Select(f => new FundraisingResponseTotalCollectedModel
                {
                    Id = f.Id,
                    Title = f.Title,
                    GoalAmount = f.GoalAmount,
                    CreatedAt = f.CreatedAt,
                    Deadline = f.Deadline,
                    TotalCollected = f.Stat != null
                        ? f.Stat.TotalCollected
                        : f.Donates.Sum(d => d.Amount),
                    IsBlocked = f.IsBlocked
                })
                .OrderByDescending(x => x.CreatedAt)
                .ToListAsync();
        }
        public async Task ToggleBlockAsync(int fundraisingId, bool isBlocked)
        {
            var f = await _ctx.Fundraisings.FindAsync(fundraisingId)
                ?? throw new KeyNotFoundException($"Fundraising #{fundraisingId} not found.");

            f.IsBlocked = isBlocked;
            await _ctx.SaveChangesAsync();
        }

        public async Task<List<FundraisingNotificationResponseModel>> GetFundraisingNotificationsAsync(int userId)
        {
            return await _ctx.FundraisingNotifications
                .Where(n => n.UserId == userId)
                .OrderByDescending(n => n.CreatedAt)
                .Select(n => new FundraisingNotificationResponseModel
                {
                    Id = n.Id,
                    FundraisingId = n.FundraisingId,
                    CreatedAt = n.CreatedAt,
                    IsRead = n.IsRead
                })
                .ToListAsync();
        }

    }
}
