﻿using AutoMapper;
using Fun.Application.Fun.IRepositories;
using Fun.Application.Fun.IServices;
using Fun.Application.IComponentModels;
using Fun.Application.ResponseModels;
using Fun.Domain.Fun.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fun.Infrastructure.Fun.Services
{
    public class SubscribeService : ISubscribeService
    {
        private readonly ICRUDRepository<Subscribe> _repo;
        private readonly IUserService _userService;
        private readonly IMapper _mapper;
        private readonly MainDataContext _db;
        private readonly IWebHostEnvironment _env;

        public SubscribeService(
            ICRUDRepository<Subscribe> repo,
            IUserService userService,
            IMapper mapper,
            MainDataContext db, IWebHostEnvironment webHostEnvironment)
        {
            _repo = repo;
            _userService = userService;
            _mapper = mapper;
            _db = db;
            _env = webHostEnvironment;
        }

        public async Task<Subscribe> CreateAsync(ISubscribeComponentModel model)
        {
            var userId = await _userService.GetMy();
            var exists = (await _repo.ListAsync())
                .Any(s => s.UserId == userId && s.InitiativeId == model.InitiativeId);
            if (exists)
                throw new ArgumentException("You have already subscribed to this initiative");

            var subscribe = _mapper.Map<Subscribe>(model);
            subscribe.UserId = userId;

            return await _repo.Create(subscribe);
        }

        public async Task DeleteAsync(int id)
        {
            var existing = await _repo.GetByIdAsync(id);
            if (existing == null) throw new KeyNotFoundException();
            //if (existing.UserId != CurrentUserId)
            //    throw new UnauthorizedAccessException();
            await _repo.Delete(id);
        }

        public async Task<List<SubscribeResponseModel>> GetMySubscribesAsync()
        {
            var userId = await _userService.GetMy();

            var subs = await _db.Subscribes
                .Where(d => d.UserId == userId)
                .Include(d => d.Initiative)
                .ToListAsync();

            var result = new List<SubscribeResponseModel>();
            foreach (var d in subs
                         .OrderByDescending(x => x.SubscribedAt))
            {
                string? base64 = null;
                var url = d.Initiative.ImageUrl;
                if (!string.IsNullOrWhiteSpace(url))
                {
                    var relative = url.TrimStart('/');
                    var fullPath = Path.Combine(_env.WebRootPath, relative);

                    if (File.Exists(fullPath))
                    {
                        var bytes = await File.ReadAllBytesAsync(fullPath);
                        var ext = Path.GetExtension(fullPath)
                                       .TrimStart('.')
                                       .ToLowerInvariant();
                        var mime = ext switch
                        {
                            "png" => "image/png",
                            "jpg" => "image/jpeg",
                            "jpeg" => "image/jpeg",
                            "gif" => "image/gif",
                            _ => "application/octet-stream"
                        };
                        base64 = Convert.ToBase64String(bytes);
                    }
                }

                result.Add(new SubscribeResponseModel
                {
                    Id = d.Id,
                    InitiativeId = d.InitiativeId,
                    SubscribedAt = d.SubscribedAt,
                    Initiative = new InitiativeSummaryModel
                    {
                        Title = d.Initiative.Title,
                        Description = d.Initiative.Description,
                        ImageBase64 = base64
                    }
                });
            }

            return result;
        }
    }
}
