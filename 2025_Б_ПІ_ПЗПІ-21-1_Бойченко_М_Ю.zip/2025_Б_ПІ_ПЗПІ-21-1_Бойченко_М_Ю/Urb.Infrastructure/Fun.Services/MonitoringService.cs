﻿using Fun.Application.ComponentModels;
using Fun.Application.Fun.IServices;
using Fun.Application.ResponseModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fun.Infrastructure.Fun.Services
{
    public class MonitoringService : IMonitoringService
    {
        private readonly MainDataContext _ctx;

        public MonitoringService(MainDataContext ctx)
        {
            _ctx = ctx;
        }

        public async Task<List<UserActivityResponseModel>> GetUserActivityAsync(UserActivityFilterModel filter)
        {
            var query = _ctx.Users
                .AsNoTracking()
                .Select(u => new UserActivityResponseModel
                {
                    UserId = u.Id,
                    Email = u.Email,
                    TotalDonated = u.Donates.Sum(d => (decimal?)d.Amount) ?? 0m,
                    DonationCount = u.Donates.Count()
                });

            if (filter.UserId.HasValue)
                query = query.Where(x => x.UserId == filter.UserId.Value);
            if (!string.IsNullOrWhiteSpace(filter.Email))
                query = query.Where(x => x.Email.Contains(filter.Email));
            if (filter.MinTotalDonated.HasValue)
                query = query.Where(x => x.TotalDonated >= filter.MinTotalDonated.Value);
            if (filter.MinDonationCount.HasValue)
                query = query.Where(x => x.DonationCount >= filter.MinDonationCount.Value);

            return await query.ToListAsync();
        }


    }
}
