﻿using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Fun.Infrastructure.Hubs
{
    public class FundraisingHub : Hub
    {
        //public override async Task OnConnectedAsync()
        //{
        //    var userId = Context.User.FindFirstValue(ClaimTypes.NameIdentifier);
        //    Console.WriteLine($"User {userId} connected");
        //    await base.OnConnectedAsync();
        //}
        //public async Task SubscribeToInitiative(int initiativeId)
        //{
        //    await Groups.AddToGroupAsync(Context.ConnectionId, $"initiative-{initiativeId}");
        //}
        //public async Task UnsubscribeFromInitiative(int initiativeId)
        //{
        //    await Groups.RemoveFromGroupAsync(Context.ConnectionId, $"initiative-{initiativeId}");
        //}
        private readonly ILogger<FundraisingHub> _logger;

        public FundraisingHub(ILogger<FundraisingHub> logger)
        {
            _logger = logger;
        }

        public override async Task OnConnectedAsync()
        {
            var userId = Context.User?.FindFirstValue(ClaimTypes.NameIdentifier) ?? "anon";
            _logger.LogInformation("Connection {ConnId} connected as User {UserId}",
                                    Context.ConnectionId, userId);
            await base.OnConnectedAsync();
        }

        public override async Task OnDisconnectedAsync(Exception? exception)
        {
            _logger.LogInformation("Connection {ConnId} disconnected", Context.ConnectionId);
            // SignalR автоматично видаляє з’єднання з усіх груп
            await base.OnDisconnectedAsync(exception);
        }

        public async Task SubscribeToInitiative(int initiativeId)
        {
            var groupName = $"initiative-{initiativeId}";
            await Groups.AddToGroupAsync(Context.ConnectionId, groupName);
            _logger.LogInformation("Conn {ConnId} SUBSCRIBED to {Group}",
                                    Context.ConnectionId, groupName);
        }

        public async Task UnsubscribeFromInitiative(int initiativeId)
        {
            var groupName = $"initiative-{initiativeId}";
            await Groups.RemoveFromGroupAsync(Context.ConnectionId, groupName);
            _logger.LogInformation("Conn {ConnId} UNSUBSCRIBED from {Group}",
                                    Context.ConnectionId, groupName);
        }
    }
}