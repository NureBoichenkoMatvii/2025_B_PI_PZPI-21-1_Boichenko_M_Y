﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fun.Application.ComponentModels
{
    public class NotificationSettingUpdateModel
    {
        public bool NotifyNewFundraising { get; set; }
        public bool NotifyNewInitiative { get; set; }
        public bool NotifyGoalReached { get; set; }
        public int FrequencyInHours { get; set; }
    }
}
