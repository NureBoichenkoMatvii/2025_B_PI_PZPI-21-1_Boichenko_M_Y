﻿using Fun.Application.IComponentModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fun.Application.ComponentModels
{
    public class CategoryComponentModel : ICategoryComponentModel
    {
        public string CategoryName { get; set; }
    }
}
