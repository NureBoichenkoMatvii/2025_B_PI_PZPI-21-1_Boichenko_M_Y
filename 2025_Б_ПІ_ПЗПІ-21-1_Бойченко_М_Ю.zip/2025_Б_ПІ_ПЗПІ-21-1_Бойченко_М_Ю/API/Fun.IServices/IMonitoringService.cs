﻿using Fun.Application.ComponentModels;
using Fun.Application.ResponseModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fun.Application.Fun.IServices
{
    public interface IMonitoringService
    {
        Task<List<UserActivityResponseModel>> GetUserActivityAsync(UserActivityFilterModel filter);
    }
}
