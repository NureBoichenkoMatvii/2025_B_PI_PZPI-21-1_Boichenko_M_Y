﻿using Fun.Application.ComponentModels;
using Fun.Application.Fun.IServices;
using Fun.Application.ResponseModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Fun.Plan.v2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SubscribeController : ControllerBase
    {
        private readonly ISubscribeService _subscribeService;

        public SubscribeController(ISubscribeService subscribeService)
        {
            _subscribeService = subscribeService;
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> Subscribe([FromBody] SubscribeComponentModel model)
        {
            var subscription = await _subscribeService.CreateAsync(model);

            return Ok(new { subscription.Id, subscription.InitiativeId, subscription.SubscribedAt });
        }

        [HttpDelete("UnsubscribeFromInitiative")]
        [Authorize]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _subscribeService.DeleteAsync(id);
                return NoContent();
            }
            catch (UnauthorizedAccessException)
            {
                return Forbid();
            }
        }

        [HttpGet("MySubscribe")]
        [Authorize]
        public async Task<ActionResult<List<DonateResponseModel>>> GetMySubscribes()
        {
            var result = await _subscribeService.GetMySubscribesAsync();
            return Ok(result);
        }
    }
}
